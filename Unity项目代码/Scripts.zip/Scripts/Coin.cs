﻿using UnityEngine;

public class Coin : MonoBehaviour
{
	static public Pooler coinPool;
    public bool isPremium = false;
}
