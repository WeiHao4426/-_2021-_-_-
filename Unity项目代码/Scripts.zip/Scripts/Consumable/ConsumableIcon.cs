﻿using UnityEngine;
using UnityEngine.UI;

public class ConsumableIcon : MonoBehaviour
{
    public Text numberTxt;
    public Image iconImg;
}
